#pragma once

#include "Node.hpp"
#include "Board.hpp"
#include "PathFinder.hpp"
//g++ -Wall -std=c++17 -o demo Main.cpp && demo